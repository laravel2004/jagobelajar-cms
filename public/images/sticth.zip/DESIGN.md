---
name: Jago Belajar Design System
colors:
  surface: '#f9f9ff'
  surface-dim: '#d2daf0'
  surface-bright: '#f9f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f3ff'
  surface-container: '#e9edff'
  surface-container-high: '#e0e8ff'
  surface-container-highest: '#dbe2f9'
  on-surface: '#141b2c'
  on-surface-variant: '#434655'
  inverse-surface: '#293041'
  inverse-on-surface: '#edf0ff'
  outline: '#737687'
  outline-variant: '#c3c5d8'
  surface-tint: '#014fe6'
  primary: '#0043c6'
  on-primary: '#ffffff'
  primary-container: '#1e5af0'
  on-primary-container: '#e4e7ff'
  inverse-primary: '#b6c4ff'
  secondary: '#7c5800'
  on-secondary: '#ffffff'
  secondary-container: '#feb700'
  on-secondary-container: '#6b4b00'
  tertiary: '#4a36c4'
  on-tertiary: '#ffffff'
  tertiary-container: '#6352dd'
  on-tertiary-container: '#eae5ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164f'
  on-primary-fixed-variant: '#003ab1'
  secondary-fixed: '#ffdea8'
  secondary-fixed-dim: '#ffba20'
  on-secondary-fixed: '#271900'
  on-secondary-fixed-variant: '#5e4200'
  tertiary-fixed: '#e4dfff'
  tertiary-fixed-dim: '#c6bfff'
  on-tertiary-fixed: '#160066'
  on-tertiary-fixed-variant: '#4029ba'
  background: '#f9f9ff'
  on-background: '#141b2c'
  surface-variant: '#dbe2f9'
typography:
  display-lg:
    fontFamily: Montserrat
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 60px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Montserrat
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Montserrat
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
  headline-sm:
    fontFamily: Montserrat
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Montserrat
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Montserrat
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  button:
    fontFamily: Montserrat
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 48px
---

## Brand & Style

The design system is built to balance academic authority with a vibrant, student-centric energy. It targets a broad age range from elementary (SD) to high school (SMA), requiring an interface that feels accessible yet capable. 

The aesthetic sits at the intersection of **Modern Corporate** and **Playful Education**. It utilizes a clean white canvas punctuated by high-energy primary colors and friendly, rounded geometry. The mood is encouraging and expert, aiming to reduce study anxiety through soft shadows, clear information hierarchy, and a rhythmic use of colorful iconography.

**Key Stylistic Pillars:**
- **Friendly Geometry:** All interactive elements feature generous corner radii to appear approachable.
- **Visual Encouragement:** Usage of vibrant accent colors to celebrate progress and achievements.
- **Clarity First:** A rigorous grid and clean sans-serif typography ensure complex educational content remains legible.

## Colors

The palette is derived from the brand's core identity, emphasizing a high-contrast relationship between a deep "Academic Blue" and a vibrant "Inspiration Yellow."

- **Primary (Blue):** Used for core branding, primary actions, and navigational anchors. It represents trust and expertise.
- **Secondary (Yellow):** Reserved for highlight moments, "Join" actions, and achievement indicators. It provides high-visibility contrast against the primary blue.
- **Tertiary (Purple/Green):** Utilized for subject categorization (e.g., Science, Math) and progress tracking to differentiate educational streams.
- **Neutrals:** A range of cool grays provides the structural skeleton. Backgrounds use an off-white tint to reduce eye strain during long study sessions.

## Typography

The design system uses **Montserrat** exclusively to maintain a modern, geometric, and consistent feel. The typeface’s large x-height and open counters make it exceptionally readable for students across different devices.

**Hierarchy Rules:**
- **Weight as Signal:** Use Bold (700) for primary value propositions and Semi-Bold (600) for section headers.
- **Color Contrast:** Headlines should typically use the Neutral Dark color, while primary Blue can be used for "hero" headlines to reinforce brand presence.
- **Mobile Scaling:** Display styles scale down significantly on mobile to ensure headlines do not push essential learning content below the fold.

## Layout & Spacing

This design system employs a **Fluid Grid** with a maximum container width to maintain readability on ultra-wide monitors. 

- **Grid System:** A 12-column grid for desktop, 8-column for tablet, and 4-column for mobile.
- **Spacing Logic:** Based on an 8px baseline. Use `stack-md` (24px) for most vertical relationships between related elements, and `stack-lg` (48px) to separate distinct content sections.
- **Density:** The layout is "breathable." White space is used intentionally around study materials to prevent cognitive overload.

## Elevation & Depth

To match the "professional and playful" requirement, depth is created through **Ambient Shadows** and **Tonal Layering**.

- **Surface Levels:** The main background is the lowest level. Cards and containers sit on Level 1 with a soft, diffused shadow (0px 4px 20px rgba(0,0,0,0.05)).
- **Interactive Depth:** Buttons and active cards use a slightly more pronounced shadow on hover to simulate "lifting" toward the user.
- **No Harsh Borders:** Avoid black borders. Use subtle 1px strokes in light gray to define boundaries if shadows are insufficient for separation.

## Shapes

The shape language is consistently **Rounded**, reinforcing the friendly and encouraging brand personality. 

- **Standard Radius:** 0.5rem (8px) for buttons, input fields, and small UI components.
- **Large Radius:** 1rem (16px) for cards, content containers, and modal windows.
- **Iconography:** Icons should feature rounded terminals and consistent stroke weights to match the typeface.

## Components

### Buttons
- **Primary:** Solid Blue or Yellow backgrounds with White or Dark Neutral text. Features a 2px lift effect on hover.
- **Secondary/Ghost:** Transparent background with a 2px primary-colored border.
- **Roundedness:** Always 8px or fully pill-shaped for special CTA buttons (like "Daftar Gratis").

### Cards
- White background with a 16px corner radius.
- Use a top-border accent color (Blue, Yellow, or Purple) to denote different course categories or subjects.
- Padding should be generous (24px to 32px) to ensure content doesn't feel cramped.

### Input Fields & Selects
- 8px corner radius with a light gray border.
- On focus, the border transitions to Primary Blue with a subtle outer glow.
- Labels are always positioned above the field for maximum clarity.

### Chips & Badges
- Used for grade levels (e.g., "SD", "SMP") and tags.
- High-pill shape (full rounding) with low-opacity background tints of the subject colors.

### Progress Indicators
- Thick, rounded progress bars using the Success Green or Primary Blue to track lesson completion, providing immediate visual satisfaction.